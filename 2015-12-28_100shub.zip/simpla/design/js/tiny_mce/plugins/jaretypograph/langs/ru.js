tinyMCE.addI18n('ru.typograph',{
	desc : 'Сделать красиво'
});
