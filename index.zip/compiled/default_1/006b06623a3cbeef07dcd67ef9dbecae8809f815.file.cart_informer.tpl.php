<?php /* Smarty version Smarty-3.0.7, created on 2012-06-06 22:43:36
         compiled from "/home/a100shub/100shub.ru/new//design/default_1/html/cart_informer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:17020628154fcfb2e85f8173-94699054%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '006b06623a3cbeef07dcd67ef9dbecae8809f815' => 
    array (
      0 => '/home/a100shub/100shub.ru/new//design/default_1/html/cart_informer.tpl',
      1 => 1338990076,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17020628154fcfb2e85f8173-94699054',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_modifier_escape')) include '/home/a100shub/100shub.ru/new/Smarty/libs/plugins/modifier.escape.php';
?><?php if ($_smarty_tpl->getVariable('cart')->value->total_products>0){?>
	В <a href="./cart/">корзине</a>
	<?php echo $_smarty_tpl->getVariable('cart')->value->total_products;?>
 <?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_MODIFIER]['plural'][0][0]->plural_modifier($_smarty_tpl->getVariable('cart')->value->total_products,'товар','товаров','товара');?>

	на <?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_MODIFIER]['convert'][0][0]->convert($_smarty_tpl->getVariable('cart')->value->total_price);?>
 <?php echo smarty_modifier_escape($_smarty_tpl->getVariable('currency')->value->sign);?>

<?php }else{ ?>
	Корзина пуста
<?php }?>
