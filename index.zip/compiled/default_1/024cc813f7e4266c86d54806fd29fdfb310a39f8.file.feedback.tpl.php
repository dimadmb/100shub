<?php /* Smarty version Smarty-3.0.7, created on 2012-06-07 16:31:37
         compiled from "/home/a100shub/100shub.ru/new//design/default_1/html/feedback.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1531271574fd0ad398fe2e4-62460270%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '024cc813f7e4266c86d54806fd29fdfb310a39f8' => 
    array (
      0 => '/home/a100shub/100shub.ru/new//design/default_1/html/feedback.tpl',
      1 => 1338990076,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1531271574fd0ad398fe2e4-62460270',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_modifier_escape')) include '/home/a100shub/100shub.ru/new/Smarty/libs/plugins/modifier.escape.php';
if (!is_callable('smarty_function_math')) include '/home/a100shub/100shub.ru/new/Smarty/libs/plugins/function.math.php';
?>
<script src="/js/baloon/js/default.js" language="JavaScript" type="text/javascript"></script>
<script src="/js/baloon/js/validate.js" language="JavaScript" type="text/javascript"></script>
<script src="/js/baloon/js/baloon.js" language="JavaScript" type="text/javascript"></script>
<link   href="/js/baloon/css/baloon.css" rel="stylesheet" type="text/css" /> 

<h1><?php echo smarty_modifier_escape($_smarty_tpl->getVariable('page')->value->name);?>
</h1>

<?php echo $_smarty_tpl->getVariable('page')->value->body;?>


<h2>Обратная связь</h2>

<?php if ($_smarty_tpl->getVariable('message_sent')->value){?>
	<?php echo smarty_modifier_escape($_smarty_tpl->getVariable('name')->value);?>
, ваше сообщение отправлено.
<?php }else{ ?>
<form class="form beedback_form" method="post">
	<?php if ($_smarty_tpl->getVariable('error')->value){?>
	<div class="message_error">
		<?php if ($_smarty_tpl->getVariable('error')->value=='captcha'){?>
		Неверно введена капча
		<?php }elseif($_smarty_tpl->getVariable('error')->value=='empty_name'){?>
		Введите имя
		<?php }elseif($_smarty_tpl->getVariable('error')->value=='empty_email'){?>
		Введите email
		<?php }elseif($_smarty_tpl->getVariable('error')->value=='empty_text'){?>
		Введите сообщение
		<?php }?>
	</div>
	<?php }?>
	<label>Имя</label>
	<input format=".+" notice="Введите имя" value="<?php echo smarty_modifier_escape($_smarty_tpl->getVariable('name')->value);?>
" name="name" maxlength="255" type="text"/>
 
	<label>Email</label>
	<input format="email" notice="Введите email" value="<?php echo smarty_modifier_escape($_smarty_tpl->getVariable('email')->value);?>
" name="email" maxlength="255" type="text"/></td>
	
	<label>Сообщение</label>
	<textarea format=".+" notice="Введите сообщение" value="<?php echo smarty_modifier_escape($_smarty_tpl->getVariable('message')->value);?>
" name="message"><?php echo smarty_modifier_escape($_smarty_tpl->getVariable('message')->value);?>
</textarea></td>

	<label for="comment_captcha">Число</label>
	<div class="captcha"><img src="captcha/image.php?<?php echo smarty_function_math(array('equation'=>'rand(10,10000)'),$_smarty_tpl);?>
"/></div> 
	<input class="input_captcha" id="comment_captcha" type="text" name="captcha_code" value="" format="\d\d\d\d" notice="Введите капчу"/>
	
	<input class="button_send" type="submit" name="feedback" value="Отправить" />
</form>
<?php }?>