<?php /* Smarty version Smarty-3.0.7, created on 2012-06-06 22:43:36
         compiled from "/home/a100shub/100shub.ru/new//design/default_1/html/page.tpl" */ ?>
<?php /*%%SmartyHeaderCode:7972015234fcfb2e8d81ce7-10944404%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '080b710acf2289c2f36db01caebcaf32903520f3' => 
    array (
      0 => '/home/a100shub/100shub.ru/new//design/default_1/html/page.tpl',
      1 => 1338990076,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7972015234fcfb2e8d81ce7-10944404',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_modifier_escape')) include '/home/a100shub/100shub.ru/new/Smarty/libs/plugins/modifier.escape.php';
?>

<!-- Заголовок страницы -->
<h1 page_id="<?php echo $_smarty_tpl->getVariable('page')->value->id;?>
"><?php echo smarty_modifier_escape($_smarty_tpl->getVariable('page')->value->name);?>
</h1>

<!-- Тело страницы -->
<?php echo $_smarty_tpl->getVariable('page')->value->body;?>

