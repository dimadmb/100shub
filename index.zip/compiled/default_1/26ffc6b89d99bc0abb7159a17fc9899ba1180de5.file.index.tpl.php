<?php /* Smarty version Smarty-3.0.7, created on 2012-06-26 07:39:27
         compiled from "/home/a100shub/100shub.ru/new//design/default_1/html/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13588597354fe93cff2f2944-90417004%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '26ffc6b89d99bc0abb7159a17fc9899ba1180de5' => 
    array (
      0 => '/home/a100shub/100shub.ru/new//design/default_1/html/index.tpl',
      1 => 1340685565,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13588597354fe93cff2f2944-90417004',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_modifier_escape')) include '/home/a100shub/100shub.ru/new/Smarty/libs/plugins/modifier.escape.php';
?><!DOCTYPE html>
<html>
<head>
	<base href="<?php echo $_smarty_tpl->getVariable('config')->value->root_url;?>
/"/>
	<title><?php echo smarty_modifier_escape($_smarty_tpl->getVariable('meta_title')->value);?>
</title>
	
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<!--meta name="viewport"    content="width=device-width" /-->
	<meta name="description" content="<?php echo smarty_modifier_escape($_smarty_tpl->getVariable('meta_description')->value);?>
" />
	<meta name="keywords"    content="<?php echo smarty_modifier_escape($_smarty_tpl->getVariable('meta_keywords')->value);?>
" />
	
	<link href="design/<?php echo smarty_modifier_escape($_smarty_tpl->getVariable('settings')->value->theme);?>
/css/style.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="design/<?php echo smarty_modifier_escape($_smarty_tpl->getVariable('settings')->value->theme);?>
/images/favicon.ico" rel="icon"          type="image/x-icon">
	<link href="design/<?php echo smarty_modifier_escape($_smarty_tpl->getVariable('settings')->value->theme);?>
/images/favicon.ico" rel="shortcut icon" type="image/x-icon">
	<link href='http://fonts.googleapis.com/css?family=PT+Serif&subset=latin,cyrillic' rel='stylesheet' type='text/css'>
	<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">	
        
	<script src="js/jquery/jquery.js"        language="JavaScript" type="text/javascript"></script>
	<script src="js/jquery/jquery-ui.min.js" language="JavaScript" type="text/javascript"></script>
	
	<?php if ($_SESSION['admin']=='admin'){?>
	<script src ="js/admintooltip/admintooltip.js" language="JavaScript" type="text/javascript"></script>
	<link   href="js/admintooltip/css/admintooltip.css" rel="stylesheet" type="text/css" /> 
	<?php }?>
        
	
	<script>
	$(function() {
		$('select[name=currency_id]').change(function() {
			$(this).closest('form').submit();
		});
	});
	</script>
	
	
	<script type="text/javascript">

	  var _gaq = _gaq || [];
	  _gaq.push(['_setAccount', 'UA-32861749-1']);
	  _gaq.push(['_setDomainName', '100shub.ru']);
	  _gaq.push(['_trackPageview']);

	  (function() {
		var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	  })();

	</script>

</head>
<body>

	<!-- Вся страница --> 
	<!-- Шапка -->
			<div id="header">
				<!-- Логотип -->
			<div id="logo"><a href="."><img src="design/<?php echo smarty_modifier_escape($_smarty_tpl->getVariable('settings')->value->theme);?>
/images/logo.png" title="<?php echo smarty_modifier_escape($_smarty_tpl->getVariable('settings')->value->site_name);?>
" alt="<?php echo smarty_modifier_escape($_smarty_tpl->getVariable('settings')->value->site_name);?>
"/></a>
                         <div id="phone">
                          <small>+7&nbsp;(926)&nbsp;</small><big>004-81-81</big>
                         </div>
                         <div id="cart_informer">
				<?php $_template = new Smarty_Internal_Template('cart_informer.tpl', $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php unset($_template);?>
			</div>
                        </div>
                       
			<!-- Логотип (The End) -->

				

				<!-- Главное меню -->
				<ul id="main_menu"> 
				<?php  $_smarty_tpl->tpl_vars['p'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('pages')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['p']->key => $_smarty_tpl->tpl_vars['p']->value){
?>
					<?php if ($_smarty_tpl->getVariable('p')->value->menu_id==1){?>
					<li <?php if ($_smarty_tpl->getVariable('page')->value&&$_smarty_tpl->getVariable('page')->value->id==$_smarty_tpl->getVariable('p')->value->id){?>class="selected"<?php }?> page_id="<?php echo $_smarty_tpl->getVariable('p')->value->id;?>
">
						<a href="<?php echo $_smarty_tpl->getVariable('p')->value->url;?>
"><?php echo smarty_modifier_escape($_smarty_tpl->getVariable('p')->value->name);?>
</a>
					</li>
					<?php }?>
				<?php }} ?>
				</ul>
				<!-- Главное меню (The End)-->
                                <div id="banner">
                                 <img src="design/<?php echo smarty_modifier_escape($_smarty_tpl->getVariable('settings')->value->theme);?>
/images/banner.png" />
                         	</div>

			</div>
			<!-- Шапка (The End)-->
 <div id="girl"></div>
                        <div id="main">
		<!-- Правая часть страницы-->
		<div id="right_side">
		<div id="right_container">
		
			
			
			<!-- Центральный блок, зависящий от текущего модуля -->
			<?php echo $_smarty_tpl->getVariable('content')->value;?>

				
		</div>
		</div> 
		<!-- Правая часть страницы (The End)-->
		
		
		<!-- Подвал сайта -->
		<div id="footer">
                
                 <div class="social">
                  <a href="#"><img src="design/<?php echo smarty_modifier_escape($_smarty_tpl->getVariable('settings')->value->theme);?>
/images/fb.png" /></a>
                  <a href="http://vk.com/n100shub_ru" target="_blank"><img src="design/<?php echo smarty_modifier_escape($_smarty_tpl->getVariable('settings')->value->theme);?>
/images/vk.png" /></a>
                  <a href="#"><img src="design/<?php echo smarty_modifier_escape($_smarty_tpl->getVariable('settings')->value->theme);?>
/images/ok.png" /></a>
                 </div>
			
			<!-- Поиск-->
			<div id="search">
				<form action="products">
					<input class="input_search" type="text" name="keyword" value="<?php echo $_smarty_tpl->getVariable('keyword')->value;?>
" />
					<input class="button_search" value="" type="submit" />
				</form>
			</div>
			<!-- Поиск (The End)-->
                 <div style="width:50px;float:left">

                 </div>
                 
                 <div class="social">
                	                 	<!-- Yandex.Metrika informer -->
<a href="http://metrika.yandex.ru/stat/?id=15566428&amp;from=informer"
target="_blank" rel="nofollow"><img src="//bs.yandex.ru/informer/15566428/3_1_FFFFFFFF_FFFFFFFF_0_pageviews"
style="width:88px; height:31px; border:0;" alt="Яндекс.Метрика" title="Яндекс.Метрика: данные за сегодня (просмотры, визиты и уникальные посетители)" onclick="try{Ya.Metrika.informer({i:this,id:15566428,type:0,lang:'ru'});return false}catch(e){}"/></a>
<!-- /Yandex.Metrika informer -->

<!-- Yandex.Metrika counter --><!-- Yandex.Metrika counter --><!-- Yandex.Metrika counter -->

<script type="text/javascript">
(function (d, w, c) {
    (w[c] = w[c] || []).push(function() {
        try {
            w.yaCounter15566428 = new Ya.Metrika({id:15566428, enableAll: true, webvisor:true});
        } catch(e) {}
    });
    
    var n = d.getElementsByTagName("script")[0],
        s = d.createElement("script"),
        f = function () { n.parentNode.insertBefore(s, n); };
    s.type = "text/javascript";
    s.async = true;
    s.src = (d.location.protocol == "https:" ? "https:" : "http:") + "//mc.yandex.ru/metrika/watch.js";

    if (w.opera == "[object Opera]") {
        d.addEventListener("DOMContentLoaded", f);
    } else { f(); }
})(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="//mc.yandex.ru/watch/15566428" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->	

                 </div>
                 
                         <div class="social">
                         
                           <!-- Yandex.Metrika counter -->
                            <script type="text/javascript">
                            (function (d, w, c) {
                                (w[c] = w[c] || []).push(function() {
                                    try {
                                        w.yaCounter15597118 = new Ya.Metrika({id:15597118, enableAll: true, webvisor:true});
                                    } catch(e) {}
                                });
                                
                                var n = d.getElementsByTagName("script")[0],
                                    s = d.createElement("script"),
                                    f = function () { n.parentNode.insertBefore(s, n); };
                                s.type = "text/javascript";
                                s.async = true;
                                s.src = (d.location.protocol == "https:" ? "https:" : "http:") + "//mc.yandex.ru/metrika/watch.js";
                            
                                if (w.opera == "[object Opera]") {
                                    d.addEventListener("DOMContentLoaded", f);
                                } else { f(); }
                            })(document, window, "yandex_metrika_callbacks");
                            </script>
                            <noscript><div><img src="//mc.yandex.ru/watch/15597118" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
                            <!-- /Yandex.Metrika counter -->	
                          
                         </div>
                         <div class="social" style="float:right; text-align:right; margin-right:-250px; margin-top:-5px;">
                          <ul>
                           <li style="float:right; padding:0px 5px 3px 5px;"><a href="http://www.new.100shub.ru/oplata" title="Условия оплаты">Условия оплаты</a></li>
                           <li style="float:right; padding:0px 5px 3px 5px;"><a href="http://www.new.100shub.ru/contact" title="Контакты">Контакты</a>
                           <li style="float:right; padding:0px 5px 3px 5px;"><a href="http://www.new.100shub.ru/blog" title="Статьи">Статьи</a>
                           <li style="float:right; padding:0px 5px 3px 5px;"><a href="http://www.new.100shub.ru/" title="Магазин">Магазин</a>
                          </ul>
                          <div style="clear:both;"></div>
                                <p>
                                 © 2012 Снежана. +7 (926) 004-81-81.<br />
 Информация на сайте не является публичной офертой.<br /> 
Цены могут быть изменены.
                         	</p>
                 	</div>
		</div>
		<!-- Подвал сайта (The End)--> 
		
	</div>
	<!-- Вся страница (The End)--> 
	
</body>
</html>